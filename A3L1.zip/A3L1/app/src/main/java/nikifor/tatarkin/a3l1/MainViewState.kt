package nikifor.tatarkin.a3l1

import nikifor.tatarkin.a3l1.data.entity.Note

class MainViewState( val notes: List<Note>)