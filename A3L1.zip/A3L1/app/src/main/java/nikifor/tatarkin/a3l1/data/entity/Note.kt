package nikifor.tatarkin.a3l1.data.entity

class Note( val title: String, val text: String, val color: Int){

}